package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.beans.Shoe;
import com.utils.DBConnection;

public class ShoeDAO {

	public static int addShoe(Shoe shoe) {
		int result = 0;
		String sql = "INSERT INTO SHOESTOCK_1382594 VALUES(?,?,?,?)";
		Connection connection = DBConnection.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, shoe.getShoeTagId());
			statement.setString(2, shoe.getBrandName());
			statement.setString(3, shoe.getType());
			statement.setInt(4, shoe.getPrice());

			result = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBConnection.closeConnection(connection);
		return result;
	}

	public static ArrayList<Shoe> readShoe() {
		String sql = "SELECT * FROM SHOESTOCK_1382594";
		ArrayList<Shoe> shoeList = new ArrayList<Shoe>();
		ResultSet rs = null;
		Connection connection = DBConnection.getConnection();
		try {
			Statement statement = connection.createStatement();
			rs = statement.executeQuery(sql);
			while (rs.next()) {
				Shoe shoe = new Shoe(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4));
				shoeList.add(shoe);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DBConnection.closeConnection(connection);
		return shoeList;
	}

	public static int updateShoe(Shoe shoe) {
		String sql = "UPDATE SHOESTOCK_1382594 SET BRANDNAME = ?, TYPE = ?, PRICE = ? WHERE SHOETAGID = ?";
		int result = 0;
		Connection connection = DBConnection.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, shoe.getBrandName());
			statement.setString(2, shoe.getType());
			statement.setInt(3, shoe.getPrice());
			statement.setString(4, shoe.getShoeTagId());
			
			result = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	public static int deleteShoe(String shoeTagId) {
		int result = 0;
		String query="delete from SHOESTOCK_1382594 WHERE shoeTagId=?";
		Connection connection = DBConnection.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			
			statement.setString(1, shoeTagId);
			
			result = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
