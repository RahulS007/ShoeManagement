package com.beans;

public class Shoe {
	private String shoeTagId = null;
	private String brandName = null;
	private String type = null;
	private int price = 0;
	
	public Shoe(String shoeTagId, String brandName, String type, int price) {
		this.shoeTagId = shoeTagId;
		this.brandName = brandName;
		this.type = type;
		this.price = price;
	}

	public String getShoeTagId() {
		return shoeTagId;
	}

	public void setShoeTagId(String shoeTagId) {
		this.shoeTagId = shoeTagId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
}
