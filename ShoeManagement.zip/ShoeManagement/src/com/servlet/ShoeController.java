package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.Shoe;
import com.service.ShoeService;

public class ShoeController extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getParameter("action");
		
		if(action.equals("add")){
			String shoeTagId = req.getParameter("shoetagid");
			String brandName = req.getParameter("brand");
			String type = req.getParameter("type");
			int price = Integer.parseInt(req.getParameter("price"));
			
			Shoe shoe = new Shoe(shoeTagId,brandName,type,price);
			
			int result = ShoeService.addShoe(shoe);
			if(result>0){
				PrintWriter out = resp.getWriter();
				out.write("<html>Shoe Added Successfully!<a href='index.jsp'>Click here</a> to go home.</html>");
			}
		}else if(action.equals("update")){
			ArrayList<Shoe> shoeList = new ArrayList<Shoe>();
			shoeList = ShoeService.readShoe();
			req.setAttribute("shoeList", shoeList);
			RequestDispatcher dispatcher = req.getRequestDispatcher("updateshoe.jsp");
			dispatcher.forward(req, resp);
		}else if(action.equals("update1")){
			String shoeTagId = req.getParameter("shoetagid");
			String brandName = req.getParameter("brand");
			String type = req.getParameter("type");
			int price = Integer.parseInt(req.getParameter("price"));
			Shoe shoe = new Shoe(shoeTagId,brandName,type,price);
			int result = ShoeService.updateShoe(shoe);
			if(result>0){
				PrintWriter out = resp.getWriter();
				out.write("<html>Shoe Updated Successfully!<a href='index.jsp'>Click here</a> to go home.</html>");
			}
			
		}else if(action.equals("getShoeList")){
			ArrayList<Shoe> shoeList = new ArrayList<Shoe>();
			shoeList = ShoeService.readShoe();
			req.setAttribute("shoeList", shoeList);
			RequestDispatcher dispatcher = req.getRequestDispatcher("deleteShoe.jsp");
			dispatcher.forward(req, resp);
		}else if(action.equals("delete1")){
			String shoeTagId=req.getParameter("shoeid");
			int result=ShoeService.deleteShoe(shoeTagId);
			if(result!=0)
			{

				PrintWriter out = resp.getWriter();
				out.write("<html>Shoe Deleted Successfully!<a href='index.jsp'>Click here</a> to go home.</html>");
			}
		}
			
		else if(action.equals("search")){
			ArrayList<Shoe> shoeList = new ArrayList<Shoe>();
			shoeList = ShoeService.readShoe();
			req.setAttribute("shoeList", shoeList);
			RequestDispatcher dispatcher = req.getRequestDispatcher("searchshoe.jsp");
			dispatcher.forward(req, resp);
		}
	}
}
