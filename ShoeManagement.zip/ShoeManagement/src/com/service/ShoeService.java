package com.service;

import java.util.ArrayList;

import com.beans.Shoe;
import com.dao.ShoeDAO;

public class ShoeService {
	public static int addShoe(Shoe shoe){
		return ShoeDAO.addShoe(shoe);
	}

	public static ArrayList<Shoe> readShoe() {
		return ShoeDAO.readShoe();
	}

	public static int updateShoe(Shoe shoe) {
		return ShoeDAO.updateShoe(shoe);
	}

	public static int deleteShoe(String shoeTagId) {
		return ShoeDAO.deleteShoe(shoeTagId);
	}
	
	
}
